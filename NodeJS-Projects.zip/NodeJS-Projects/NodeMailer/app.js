// app.js
const express = require('express');
const app = express();
const nodemailer = require('nodemailer');

// Middleware pour parser le corps des requêtes
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

// Route pour envoyer un e-mail
app.post('/envoyer-email', (req, res) => {
  const { destinataire, sujet, contenu } = req.body;

  // Configuration du service d'envoi d'e-mails (ici, nous utilisons Gmail, mais vous pouvez utiliser un autre fournisseur)
  const transporter = nodemailer.createTransport({
    service: 'Gmail',
    auth: {
      user: 'votre_adresse_email@gmail.com',
      pass: 'votre_mot_de_passe_email'
    }
  });

  // Options de l'e-mail à envoyer
  const mailOptions = {
    from: 'votre_adresse_email@gmail.com',
    to: destinataire,
    subject: sujet,
    text: contenu
  };

  // Envoi de l'e-mail
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.log(error);
      res.status(500).send('Erreur lors de l\'envoi de l\'e-mail');
    } else {
      console.log('E-mail envoyé : ' + info.response);
      res.send('E-mail envoyé avec succès !');
    }
  });
});

// Démarrage du serveur
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Serveur en cours d'exécution sur le port ${PORT}`);
});
