const express = require("express");
const path = require("path");
const router = express.Router();

// Route pour la page d'accueil (sans paramètre)
router.get("/", (req, res) => {
  const filePath = path.join(__dirname, "html", "accueil.html");

  res.sendFile(filePath, (err) => {
    if (err) {
      console.error("Erreur lors de l'envoi du fichier :", err);
      res.status(500).json({
        error: "Erreur interne du serveur"
      });
    }
  });
});

// Route dynamique pour les autres pages
router.get("/:page", (req, res) => {
  const page = req.params.page;
  const filePath = path.join(__dirname, "html", `${page}.html`);

  res.sendFile(filePath, (err) => {
    if (err) {
      console.error("Erreur lors de l'envoi du fichier :", err);
      res.status(500).json({
        error: "Erreur interne du serveur"
      });
    }
  });
});

// Route pour toutes les autres pages (404 - Page introuvable)
router.use((req, res) => {
  const errorFilePath = path.join(__dirname, "html", "error.html");
  res.status(404).sendFile(errorFilePath);
});

module.exports = router;
