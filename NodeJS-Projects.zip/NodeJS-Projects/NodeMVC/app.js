// app.js
const express = require('express');
const app = express();
const userController = require('./controllers/userController');

// Configuration du moteur de template EJS
app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');

// Route pour la page d'accueil
app.get('/', userController);

// Lancement du serveur
const port = 3000;
app.listen(port, () => {
  console.log(`Le serveur est en cours d'exécution sur http://localhost:${port}`);
});
