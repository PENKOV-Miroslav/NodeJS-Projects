// controllers/userController.js
const User = require('../models/User');

// Liste d'utilisateurs (simulée pour les besoins de la démo)
const users = [
  new User('Alice', 'alice@example.com'),
  new User('Bob', 'bob@example.com'),
  new User('Eve', 'eve@example.com'),
];

// Contrôleur pour la page d'accueil
const homeController = (req, res) => {
  res.render('index', { users });
};

module.exports = homeController;
