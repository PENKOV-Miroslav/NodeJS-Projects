const express = require('express');
const app = express();
const path = require('path');

// Configuration du moteur de template EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Configuration des fichiers statiques (CSS, images, etc.)
app.use('/contenu', express.static(path.join(__dirname, 'contenu')));

// Middleware pour traiter les données du formulaire
app.use(express.urlencoded({ extended: true }));

// Importez les routes depuis le fichier "routes.js"
const routes = require('./routes');
app.use('/', routes);

// Lancement du serveur
const port = 3000;
app.listen(port, () => {
  console.log(`Le serveur est en cours d'exécution sur http://localhost:${port}`);
});

// Ce middleware permet de rediriger Error 404 not found

app.use((req, res, next) => {
  res.status(404).render('error'); // Rend la vue EJS error.ejs
});

