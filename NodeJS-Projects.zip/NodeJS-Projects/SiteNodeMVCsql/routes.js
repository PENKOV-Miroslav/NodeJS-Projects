const express = require('express');
const router = express.Router();
const userController = require('./controllers/userController');

// Route pour la page d'accueil
router.get('/', userController.home);

// Route pour traiter la soumission du formulaire
router.post('/save', userController.save);

// Route pour afficher le formulaire d'édition de l'utilisateur
router.get('/edit/:userId', userController.edit);

// Route pour traiter la soumission du formulaire d'édition
router.post('/update/:userId', userController.update);

// Route pour supprimer un utilisateur (utilisez /delete/:userId)
router.post('/delete/:userId', userController.delete);

module.exports = router;
