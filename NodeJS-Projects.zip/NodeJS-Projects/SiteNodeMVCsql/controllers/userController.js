// controllers/userController.js
const User = require('../models/User');

// Contrôleur pour la page d'accueil
const homeController = async (req, res) => {
  try {
    const users = await User.getAll();
    res.render('index', { users });
  } catch (error) {
    console.error(error); // Affiche l'erreur dans la console du serveur
    res.status(500).send('Erreur lors de la récupération des utilisateurs depuis le contrôleur');
  }
};

// Contrôleur pour traiter la soumission du formulaire
const saveController = async (req, res) => {
  const { name, email } = req.body;
  const user = new User(name, email);
  try {
    const userId = await user.save();
    console.log(`Utilisateur enregistré avec l'ID : ${userId}`);
    res.redirect('/');
  } catch (error) {
    res.status(500).send('Erreur lors de l\'enregistrement de l\'utilisateur');
  }
};

// Contrôleur pour supprimer un utilisateur
const deleteController = async (req, res) => {
    const userId = req.params.userId;
    try {
      await User.delete(userId);
      console.log(`Utilisateur avec l'ID ${userId} supprimé`);
      res.redirect('/');
    } catch (error) {
      res.status(500).send('Erreur lors de la suppression de l\'utilisateur');
    }
  };

  // Contrôleur pour afficher le formulaire de modification
const editController = async (req, res) => {
  const userId = req.params.userId;
  try {
    // Récupérer les informations de l'utilisateur à partir de la base de données
    const user = await User.getOne(userId);
    // Afficher le formulaire de modification avec les informations de l'utilisateur en tant que valeurs par défaut
    res.render('edit', { user });
  } catch (error) {
    res.status(500).send('Erreur lors de la récupération des informations de l\'utilisateur pour la modification');
  }
};

const updateController = async (req, res) => {
  const userId = req.params.userId;
  const { name, email } = req.body;

  try {
    // Avant la mise à jour
    console.log('Informations avant la mise à jour :', { userId, name, email });

    // Appeler la méthode de mise à jour dans le modèle User pour mettre à jour les informations de l'utilisateur
    await User.update(userId, name, email);
    console.log(`Informations de l'utilisateur avec l'ID ${userId} mises à jour`);

    // Rediriger vers la page d'accueil après la mise à jour
    res.redirect('/');
  } catch (error) {
    console.error(error);
    res.status(500).send('Erreur lors de la mise à jour des informations de l\'utilisateur');
  }
};
  
module.exports = {
  home: homeController,
  save: saveController,
  delete: deleteController,
  edit: editController,
  update: updateController,
};
